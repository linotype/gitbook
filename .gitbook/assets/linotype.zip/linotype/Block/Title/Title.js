import { Controller } from "stimulus"

export default class extends Controller {

  initialize() {
    // console.log("Hello, Stimulus Title!", this.element)

  }

}